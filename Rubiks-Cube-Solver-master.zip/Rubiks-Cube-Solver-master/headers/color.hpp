//
// Created by nathan on 05/02/16.
//

#ifndef RUBKIS_COLOR_H
#define RUBKIS_COLOR_H

#endif //RUBKIS_COLOR_H

/*
 *
 * This file holds the enums that represent different colors in a cube
 *
 */

enum Color { white, red, green, blue, orange, yellow };

